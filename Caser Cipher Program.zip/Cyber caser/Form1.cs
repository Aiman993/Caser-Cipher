﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cyber_caser
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }
        // هاوكێشه‌ی بیركاری مۆده‌كه‌
        public static int Mod(int a, int n)
        {
            return a - (int)Math.Floor((double)a / n) * n;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        string alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        private void btn_Encrypt_Text_Click(object sender, EventArgs e)
        {
            txt_cyber_Text.Clear();
            txt_Original_Text.Clear();
            /*
              لێره‌ ئه‌گه‌ر (message & key) نه‌دابوو
            ئه‌وا ئه‌م نامه‌یه‌مان پیان بدات  
            */
            if(txt_Message.Text == "" || txt_Key.Text == "")
            {
                MessageBox.Show("Some of the required fields are empty");
            }

            //لێره‌وه‌ ده‌ستپێده‌كه‌ین
            else
            {
                string charToUpper = txt_Message.Text.ToUpper();
                // كردمان ناو Array Char بۆ ئه‌وه‌ی پیت پیت ده‌ستكاری بكه‌ین
                char[] plan = charToUpper.ToCharArray();

                // plan is the message
                for(int i = 0; i < plan.Length; i++)
                {
                    if (alphabet.Contains(plan[i]))
                    {
                        
                        int planNumber = alphabet.IndexOf(plan[i]);
                        // ئه‌نجامی (plan & key) ئه‌بێته‌ Index بۆ alphabet
                        txt_cyber_Text.Text += alphabet[ Mod(planNumber + Convert.ToInt32(txt_Key.Text), 26)];
                    }
                    else
                    {
                        txt_cyber_Text.Text += plan[i];
                    }
                }
                btn_Decode.Enabled = true;
            }
        }

        private void btn_Decode_Click(object sender, EventArgs e)
        {
            if(txt_Key.Text == "" || txt_cyber_Text.Text == "")
            {
                MessageBox.Show("Some of the required fields are empty");
            }
            else
            {
                // نامه‌ی ڕه‌مزكراو واته‌ گۆڕاو
                string charToUpper = txt_cyber_Text.Text.ToUpper();

                char[] Cipher = charToUpper.ToCharArray();

                for(int i = 0; i < Cipher.Length; i++)
                {
                    if (alphabet.Contains(Cipher[i]) == true)
                    {
                        int CipherNumber = alphabet.IndexOf(Cipher[i]);
                        txt_Original_Text.Text += alphabet[Mod(CipherNumber - Convert.ToInt32(txt_Key.Text), 26)];
                    }
                    else
                    {
                        txt_Original_Text.Text += Cipher[i];
                    }
                }
                
            }
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            txt_Message.Text = "";
            txt_Message.Clear();
            txt_Original_Text.Clear();
            txt_cyber_Text.Clear();
            txt_Key.Clear();
            btn_Decode.Enabled = false;
        }

        
    }
}
