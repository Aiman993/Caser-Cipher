﻿namespace Cyber_caser
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.txt_Message = new System.Windows.Forms.TextBox();
            this.btn_Encrypt_Text = new System.Windows.Forms.Button();
            this.txt_Key = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txt_Original_Text = new System.Windows.Forms.TextBox();
            this.btn_Clear = new System.Windows.Forms.Button();
            this.txt_cyber_Text = new System.Windows.Forms.TextBox();
            this.btn_Decode = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // txt_Message
            // 
            this.txt_Message.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txt_Message.Location = new System.Drawing.Point(6, 26);
            this.txt_Message.Multiline = true;
            this.txt_Message.Name = "txt_Message";
            this.txt_Message.Size = new System.Drawing.Size(547, 103);
            this.txt_Message.TabIndex = 0;
            // 
            // btn_Encrypt_Text
            // 
            this.btn_Encrypt_Text.Location = new System.Drawing.Point(559, 26);
            this.btn_Encrypt_Text.Name = "btn_Encrypt_Text";
            this.btn_Encrypt_Text.Size = new System.Drawing.Size(144, 46);
            this.btn_Encrypt_Text.TabIndex = 1;
            this.btn_Encrypt_Text.Text = "Encrypt text";
            this.btn_Encrypt_Text.UseVisualStyleBackColor = true;
            this.btn_Encrypt_Text.Click += new System.EventHandler(this.btn_Encrypt_Text_Click);
            // 
            // txt_Key
            // 
            this.txt_Key.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txt_Key.Location = new System.Drawing.Point(403, 194);
            this.txt_Key.Name = "txt_Key";
            this.txt_Key.Size = new System.Drawing.Size(157, 36);
            this.txt_Key.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txt_Message);
            this.groupBox1.Controls.Add(this.btn_Encrypt_Text);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(718, 149);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Encrypt message";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Poppins Medium", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(566, 194);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 28);
            this.label1.TabIndex = 4;
            this.label1.Text = "Key encryption";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txt_Original_Text);
            this.groupBox2.Controls.Add(this.btn_Clear);
            this.groupBox2.Controls.Add(this.txt_cyber_Text);
            this.groupBox2.Controls.Add(this.btn_Decode);
            this.groupBox2.Location = new System.Drawing.Point(12, 269);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(718, 300);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Decrypt";
            // 
            // txt_Original_Text
            // 
            this.txt_Original_Text.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txt_Original_Text.Location = new System.Drawing.Point(11, 152);
            this.txt_Original_Text.Multiline = true;
            this.txt_Original_Text.Name = "txt_Original_Text";
            this.txt_Original_Text.Size = new System.Drawing.Size(547, 103);
            this.txt_Original_Text.TabIndex = 2;
            // 
            // btn_Clear
            // 
            this.btn_Clear.Location = new System.Drawing.Point(564, 152);
            this.btn_Clear.Name = "btn_Clear";
            this.btn_Clear.Size = new System.Drawing.Size(144, 46);
            this.btn_Clear.TabIndex = 3;
            this.btn_Clear.Text = "Clear";
            this.btn_Clear.UseVisualStyleBackColor = true;
            this.btn_Clear.Click += new System.EventHandler(this.btn_Clear_Click);
            // 
            // txt_cyber_Text
            // 
            this.txt_cyber_Text.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txt_cyber_Text.Location = new System.Drawing.Point(6, 26);
            this.txt_cyber_Text.Multiline = true;
            this.txt_cyber_Text.Name = "txt_cyber_Text";
            this.txt_cyber_Text.Size = new System.Drawing.Size(547, 103);
            this.txt_cyber_Text.TabIndex = 0;
            // 
            // btn_Decode
            // 
            this.btn_Decode.Enabled = false;
            this.btn_Decode.Location = new System.Drawing.Point(559, 26);
            this.btn_Decode.Name = "btn_Decode";
            this.btn_Decode.Size = new System.Drawing.Size(144, 46);
            this.btn_Decode.TabIndex = 1;
            this.btn_Decode.Text = "Decoding Text";
            this.btn_Decode.UseVisualStyleBackColor = true;
            this.btn_Decode.Click += new System.EventHandler(this.btn_Decode_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(741, 587);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txt_Key);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Caesar Cipher";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_Message;
        private System.Windows.Forms.Button btn_Encrypt_Text;
        private System.Windows.Forms.TextBox txt_Key;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txt_cyber_Text;
        private System.Windows.Forms.Button btn_Decode;
        private System.Windows.Forms.TextBox txt_Original_Text;
        private System.Windows.Forms.Button btn_Clear;
    }
}

